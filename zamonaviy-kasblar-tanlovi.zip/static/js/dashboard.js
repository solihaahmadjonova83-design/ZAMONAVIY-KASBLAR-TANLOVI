// Dashboard logic for authenticated users
let currentUser = null;

document.addEventListener('DOMContentLoaded', async () => {
  initLanguage();
  await loadUserProfile();
  initTaskSubmissionForm();
  initProfileSettingsForm();
});

async function loadUserProfile() {
  try {
    const res = await fetch('/api/me');
    if (!res.ok) {
      window.location.href = '/login';
      return;
    }
    const data = await res.json();
    currentUser = data.user;
    renderUserDashboard(currentUser);
  } catch (e) {
    console.error('Error fetching user:', e);
  }
}

function renderUserDashboard(user) {
  if (!user) return;

  // Header display
  const nameEl = document.getElementById('dash-user-name');
  if (nameEl) nameEl.textContent = user.name;

  const emailEl = document.getElementById('dash-user-email');
  if (emailEl) emailEl.textContent = user.email;

  const avatarInitialEl = document.getElementById('dash-avatar-initial');
  if (avatarInitialEl) {
    avatarInitialEl.textContent = user.name.charAt(0).toUpperCase();
  }

  // Profession Badge
  const profBadge = document.getElementById('dash-profession-badge');
  const profNames = {
    web_dev: { uz: 'Web sayt yaratish', ru: 'Веб-разработка', en: 'Website Development' },
    web_design: { uz: 'Web dizayner', ru: 'Веб-дизайнер', en: 'Web Designer' },
    mobilography: { uz: 'Mobilograf', ru: 'Мобилограф', en: 'Mobilographer' }
  };
  if (profBadge) {
    profBadge.textContent = (profNames[user.profession] && profNames[user.profession][currentLang]) || user.profession;
  }

  // Status Badge
  const statusBadge = document.getElementById('dash-status-badge');
  const statusMap = {
    registered: { uz: 'Ro‘yxatdan o‘tilgan', ru: 'Зарегистрирован', en: 'Registered', color: 'badge-blue' },
    task_submitted: { uz: 'Topshiriq topshirilgan', ru: 'Работа отправлена', en: 'Task Submitted', color: 'badge-amber' },
    under_review: { uz: 'Hakamlar tekshiruvida', ru: 'На проверке', en: 'Under Review', color: 'badge-purple' },
    evaluated: { uz: 'Baholangan', ru: 'Оценено', en: 'Evaluated', color: 'badge-emerald' }
  };
  const currentStatus = statusMap[user.competition_status] || statusMap.registered;
  if (statusBadge) {
    statusBadge.textContent = currentStatus[currentLang] || currentStatus.uz;
    statusBadge.className = `status-pill ${currentStatus.color}`;
  }

  // Progress Bar calculation
  let progress = 25;
  if (user.phone || user.telegram) progress += 15;
  if (user.task_submission_url) progress += 35;
  if (user.score !== null && user.score !== undefined) progress = 100;

  const progBar = document.getElementById('profile-prog-bar');
  const progVal = document.getElementById('profile-prog-val');
  if (progBar) progBar.style.width = `${progress}%`;
  if (progVal) progVal.textContent = `${progress}%`;

  // Pre-fill profile settings
  const nameInput = document.getElementById('settings-name');
  if (nameInput) nameInput.value = user.name || '';

  const emailInput = document.getElementById('settings-email');
  if (emailInput) emailInput.value = user.email || '';

  const profSelect = document.getElementById('settings-profession');
  if (profSelect) profSelect.value = user.profession || 'web_dev';

  const phoneInput = document.getElementById('settings-phone');
  if (phoneInput) phoneInput.value = user.phone || '';

  const tgInput = document.getElementById('settings-telegram');
  if (tgInput) tgInput.value = user.telegram || '';

  // Task form pre-fill
  const subUrlInput = document.getElementById('task-submission-url');
  if (subUrlInput && user.task_submission_url) {
    subUrlInput.value = user.task_submission_url;
  }

  const subNotesInput = document.getElementById('task-submission-notes');
  if (subNotesInput && user.task_submission_notes) {
    subNotesInput.value = user.task_submission_notes;
  }

  const taskNotice = document.getElementById('task-status-notice');
  if (taskNotice && user.task_submission_url) {
    taskNotice.style.display = 'block';
  }

  // Score display in Results card
  const scoreBox = document.getElementById('results-score-display');
  if (scoreBox) {
    if (user.score !== null && user.score !== undefined) {
      scoreBox.innerHTML = `
        <div class="score-number-big">${user.score} / 100</div>
        <p class="score-feedback">"${user.jury_feedback || 'Ajoyib natija va professional ijro!'}"</p>
        <button class="btn btn-secondary" onclick="generateCertificate('${user.name}', '${user.profession}', ${user.score})">
          📜 Elektron Sertifikatni Yuklab Olish
        </button>
      `;
    } else if (user.task_submission_url) {
      scoreBox.innerHTML = `
        <div class="pending-state">
          <span style="font-size: 2rem;">⏳</span>
          <p>Topshirig‘ingiz qabul qilingan. Hakamlar hay’ati 10-20 noyabr kunlari ballarni e’lon qiladi.</p>
        </div>
      `;
    } else {
      scoreBox.innerHTML = `
        <div class="empty-state">
          <p>Topshiriq hali topshirilmagan. Natijalarni ko‘rish uchun loyihangiz havolasini yuboring.</p>
        </div>
      `;
    }
  }

  // Render specific guidelines for chosen profession
  renderProfessionDetails(user.profession);
}

function renderProfessionDetails(prof) {
  const container = document.getElementById('profession-brief-container');
  if (!container) return;

  const data = {
    web_dev: {
      uz: {
        title: "Web sayt yaratish yo‘nalishi talablari",
        desc: "Zamonaviy veb platforma ishlab chiqish topshirig‘i. Loyiha to‘liq moslashuvchan (responsive), toza kodli va yuqori tezlikka ega bo‘lishi shart.",
        points: [
          "HTML5 semantik teglari va zamonaviy CSS (Flexbox/Grid/Tailwind)",
          "JavaScript (ES6+) yoki zamonaviy freymvork (React, Vue, Svelte)",
          "Barcha qurilmalarda (Desktop, planshet, mobil) to‘g‘ri ishlashi",
          "Kod GitHub omboriga joylanishi va README faylida o‘rnatish ko‘rsatmalari bo‘lishi lozim"
        ]
      },
      ru: {
        title: "Требования по направлению «Веб-разработка»",
        desc: "Разработка современной веб-платформы. Проект должен быть полностью адаптивным, с чистым кодом и высокой скоростью загрузки.",
        points: [
          "Семантический HTML5 и современный CSS (Flexbox/Grid/Tailwind)",
          "JavaScript (ES6+) или современный фреймворк (React, Vue, Svelte)",
          "Идеальная работа на всех устройствах (ПК, планшет, смартфон)",
          "Проект должен быть опубликован на GitHub с инструкцией в README"
        ]
      },
      en: {
        title: "Website Development Track Requirements",
        desc: "Develop a modern web platform. The project must be fully responsive, adhere to clean code principles, and achieve high performance.",
        points: [
          "Semantic HTML5 and modern CSS (Flexbox/Grid/Tailwind)",
          "JavaScript (ES6+) or a modern framework (React, Vue, Svelte)",
          "Flawless display on all devices (Desktop, Tablet, Mobile)",
          "Repository on GitHub with clear setup instructions in README"
        ]
      }
    },
    web_design: {
      uz: {
        title: "Web dizayner yo‘nalishi talablari",
        desc: "Kreativ veb interfeys va mahsulot dizayni. Figma dasturida to‘liq UI kit, tipografika va interaktiv prototip tayyorlanishi kerak.",
        points: [
          "Desktop (1440px) va Mobile (390px) to‘liq ekranlari",
          "Komponentlar tizimi (Auto-layout, Variants, Variables)",
          "Foydalanuvchi qulayligi (UX) va qorong‘i/yorug‘ rejim vizuali",
          "Figma loyiha havolasi (ko‘rish huquqi ochiq holda) topshirilishi lozim"
        ]
      },
      ru: {
        title: "Требования по направлению «Веб-дизайнер»",
        desc: "Креативный веб-интерфейс и дизайн цифрового продукта. В Figma требуется подготовить UI kit, типографику и интерактивный прототип.",
        points: [
          "Макеты для Desktop (1440px) и Mobile (390px)",
          "Дизайн-система (Auto-layout, Варианты, Переменные)",
          "UX-эргономика и визуальная эстетика",
          "Публичная ссылка на проект в Figma"
        ]
      },
      en: {
        title: "Web Designer Track Requirements",
        desc: "Design an innovative web interface. Build a comprehensive UI kit, typographic scale, and interactive clickable prototype in Figma.",
        points: [
          "Desktop (1440px) and Mobile (390px) responsive layouts",
          "Component library (Auto-layout, Variants, Design Tokens)",
          "Intuitive UX workflows and visual polish",
          "Public viewable link to Figma canvas"
        ]
      }
    },
    mobilography: {
      uz: {
        title: "Mobilograf yo‘nalishi talablari",
        desc: "Smartfon yordamida olingan yuqori sifatli video rolik. Dinamik montaj, to‘g‘ri rang korreksiyasi va qiziqarli hikoya (storytelling).",
        points: [
          "Vertikal format (9:16) 1080p yoki 4K 60fps",
          "Davomiyligi: 30 soniyadan 90 soniyagacha",
          "Original musiqiy ritm, ovoz effektlari va montaj o‘tishlari (transitions)",
          "Video Google Drive yoki YouTube/Telegram havolasi orqali topshiriladi"
        ]
      },
      ru: {
        title: "Требования по направлению «Мобилограф»",
        desc: "Высококачественный видеоролик, снятый на смартфон. Динамичный монтаж, цветокоррекция и сторителлинг.",
        points: [
          "Вертикальный формат (9:16) 1080p или 4K 60fps",
          "Хронометраж: от 30 до 90 секунд",
          "Синхронизация с ритмом музыки, саунд-дизайн и плавные переходы",
          "Ссылка на Google Drive или YouTube/Telegram с открытым доступом"
        ]
      },
      en: {
        title: "Mobilographer Track Requirements",
        desc: "High-grade cinematic video crafted using a smartphone. Showcase dynamic pacing, color grading, and compelling storytelling.",
        points: [
          "Vertical 9:16 aspect ratio at 1080p or 4K 60fps",
          "Duration: 30 to 90 seconds",
          "Sound design, rhythmic cuts, and seamless transitions",
          "Accessible Google Drive or YouTube/Telegram video link"
        ]
      }
    }
  };

  const profInfo = (data[prof] && data[prof][currentLang]) || data.web_dev.uz;
  container.innerHTML = `
    <h3 style="font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 0.5rem;">${profInfo.title}</h3>
    <p style="color: var(--text-secondary); margin-bottom: 1.25rem; font-size: 0.95rem;">${profInfo.desc}</p>
    <ul style="list-style: none; display: flex; flex-direction: column; gap: 0.6rem;">
      ${profInfo.points.map(p => `
        <li style="display: flex; align-items: flex-start; gap: 0.65rem; color: #cbd5e1; font-size: 0.9rem;">
          <span style="color: var(--accent-cyan); font-weight: bold;">✔</span> ${p}
        </li>
      `).join('')}
    </ul>
  `;
}

function initTaskSubmissionForm() {
  const form = document.getElementById('task-submission-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submission_url = document.getElementById('task-submission-url').value.trim();
    const submission_notes = document.getElementById('task-submission-notes').value.trim();

    if (!submission_url) {
      showToast(t('dash_url_label') + ' kiritilishi shart!', 'error');
      return;
    }

    const btn = form.querySelector('button[type="submit"]');
    const oldText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '⏳ Yuborilmoqda...';

    try {
      const res = await fetch('/api/submit-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submission_url, submission_notes })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast(t('alert_task_success'), 'success');
        await loadUserProfile();
      } else {
        showToast(data.message || t('alert_error_generic'), 'error');
      }
    } catch (err) {
      showToast(t('alert_error_generic'), 'error');
    } finally {
      btn.disabled = false;
      btn.innerHTML = oldText;
    }
  });
}

function initProfileSettingsForm() {
  const form = document.getElementById('profile-settings-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('settings-name').value.trim();
    const email = document.getElementById('settings-email').value.trim();
    const profession = document.getElementById('settings-profession').value;
    const phone = document.getElementById('settings-phone').value.trim();
    const telegram = document.getElementById('settings-telegram').value.trim();
    const password = document.getElementById('settings-password').value;

    if (!name) {
      showToast(t('val_name_required'), 'error');
      return;
    }

    const btn = form.querySelector('button[type="submit"]');
    const oldText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '⏳ Saqlanmoqda...';

    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, profession, phone, telegram, password, language: currentLang })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast(t('alert_profile_updated'), 'success');
        await loadUserProfile();
      } else {
        showToast(data.message || t('alert_error_generic'), 'error');
      }
    } catch (err) {
      showToast(t('alert_error_generic'), 'error');
    } finally {
      btn.disabled = false;
      btn.innerHTML = oldText;
    }
  });
}

function generateCertificate(name, profession, score) {
  alert(`🏆 Rasmiy Sertifikat:\n\nIshtirokchi: ${name}\nYo‘nalish: ${profession.toUpperCase()}\nTo‘plangan ball: ${score} / 100\nHolat: Muvaffaqiyatli himoya qilindi!\n\n(Yuklab olish uchun PDF sertifikat tayyorlanmoqda)`);
}
