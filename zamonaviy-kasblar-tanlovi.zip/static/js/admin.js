// Admin panel logic
let allParticipants = [];
let selectedParticipantId = null;

document.addEventListener('DOMContentLoaded', async () => {
  initLanguage();
  await loadAdminStats();
  await loadParticipants();
  initAdminFilters();
  initGradeModal();
});

async function loadAdminStats() {
  try {
    const res = await fetch('/api/stats');
    if (!res.ok) return;
    const stats = await res.json();

    document.getElementById('stat-total-users').textContent = stats.total_participants;
    document.getElementById('stat-web-dev').textContent = stats.web_dev;
    document.getElementById('stat-web-design').textContent = stats.web_design;
    document.getElementById('stat-mobilography').textContent = stats.mobilography;
    document.getElementById('stat-submissions').textContent = stats.submissions;
  } catch (e) {
    console.error('Error fetching admin stats:', e);
  }
}

async function loadParticipants() {
  const prof = document.getElementById('admin-filter-prof').value;
  const search = document.getElementById('admin-search-input').value.trim();

  try {
    const res = await fetch(`/api/admin/participants?profession=${prof}&search=${encodeURIComponent(search)}`);
    if (!res.ok) {
      if (res.status === 403) window.location.href = '/login';
      return;
    }
    allParticipants = await res.json();
    renderParticipantsTable(allParticipants);
  } catch (e) {
    console.error('Error loading participants:', e);
  }
}

function renderParticipantsTable(users) {
  const tbody = document.getElementById('admin-table-body');
  if (!tbody) return;

  if (users.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 2rem; color: var(--text-muted);">
          Hech qanday ishtirokchi topilmadi.
        </td>
      </tr>
    `;
    return;
  }

  const profLabels = {
    web_dev: 'Web sayt yaratish',
    web_design: 'Web dizayner',
    mobilography: 'Mobilograf'
  };

  tbody.innerHTML = users.map(u => {
    const submissionHtml = u.task_submission_url
      ? `<a href="${u.task_submission_url}" target="_blank" class="table-link">🔗 Havolani ko‘rish</a>`
      : `<span style="color: var(--text-muted); font-size: 0.85rem;">Yuklanmagan</span>`;

    const scoreHtml = u.score !== null && u.score !== undefined
      ? `<span class="score-badge">${u.score} ball</span>`
      : `<span style="color: var(--text-muted); font-size: 0.85rem;">Baholanmagan</span>`;

    return `
      <tr>
        <td>
          <div style="font-weight: 700; color: #fff;">${u.name}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${u.email}</div>
        </td>
        <td>
          <span class="prof-pill">${profLabels[u.profession] || u.profession}</span>
        </td>
        <td>
          <span class="status-indicator status-${u.competition_status}">
            ${u.competition_status}
          </span>
        </td>
        <td>${submissionHtml}</td>
        <td>${scoreHtml}</td>
        <td>
          <button class="btn-sm btn-grade" onclick="openGradeModal(${u.id}, '${u.name.replace(/'/g, "\\'")}', ${u.score || "null"}, '${(u.jury_feedback || "").replace(/'/g, "\\'")}')">
            ⭐ Baholash
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function initAdminFilters() {
  const searchInput = document.getElementById('admin-search-input');
  const profSelect = document.getElementById('admin-filter-prof');

  if (searchInput) {
    let debounce;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(loadParticipants, 300);
    });
  }

  if (profSelect) {
    profSelect.addEventListener('change', loadParticipants);
  }
}

function initGradeModal() {
  const form = document.getElementById('grade-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!selectedParticipantId) return;

    const score = parseFloat(document.getElementById('grade-score').value);
    const feedback = document.getElementById('grade-feedback').value.trim();

    try {
      const res = await fetch('/api/admin/grade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participant_id: selectedParticipantId,
          score,
          feedback,
          status: 'evaluated'
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast('Ishtirokchi muvaffaqiyatli baholandi!', 'success');
        closeModal('grade-modal');
        await loadParticipants();
        await loadAdminStats();
      } else {
        showToast('Xatolik yuz berdi', 'error');
      }
    } catch (err) {
      showToast('Xatolik yuz berdi', 'error');
    }
  });
}

function openGradeModal(userId, name, currentScore, currentFeedback) {
  selectedParticipantId = userId;
  document.getElementById('grade-participant-name').textContent = name;
  document.getElementById('grade-score').value = currentScore !== null ? currentScore : '';
  document.getElementById('grade-feedback').value = currentFeedback || '';
  openModal('grade-modal');
}
