// Main Application Client Logic
let currentLang = localStorage.getItem('zk_lang') || 'uz';

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  initLanguage();
  initModals();
  initFaqAccordion();
  initAuthForms();
  initMobileNav();
  loadWinnersData();

  // Check URL query parameters for auto opening modal
  const urlParams = new URLSearchParams(window.location.search);
  const authAction = urlParams.get('auth');
  const profParam = urlParams.get('profession');

  if (authAction === 'login') {
    openModal('login-modal');
  } else if (authAction === 'register') {
    openModal('register-modal', profParam);
  }
});

// ===================================================================
// MULTILINGUAL SYSTEM
// ===================================================================

function initLanguage() {
  setLanguage(currentLang);

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute('data-lang');
      setLanguage(lang);
    });
  });
}

function setLanguage(lang) {
  if (!TRANSLATIONS[lang]) return;
  currentLang = lang;
  localStorage.setItem('zk_lang', lang);

  // Update active buttons
  document.querySelectorAll('.lang-btn').forEach(btn => {
    if (btn.getAttribute('data-lang') === lang) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Update elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (TRANSLATIONS[lang][key] !== undefined) {
      el.innerHTML = TRANSLATIONS[lang][key];
    }
  });

  // Update placeholders
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const key = el.getAttribute('data-i18n-ph');
    if (TRANSLATIONS[lang][key] !== undefined) {
      el.placeholder = TRANSLATIONS[lang][key];
    }
  });

  // Re-render winners cards for localized achievement & prize
  renderWinnersCards();
}

function t(key) {
  return (TRANSLATIONS[currentLang] && TRANSLATIONS[currentLang][key]) || key;
}

// ===================================================================
// MODALS LOGIC
// ===================================================================

function initModals() {
  // Close buttons
  document.querySelectorAll('.modal-close-btn, .modal-backdrop').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop') || e.target.closest('.modal-close-btn')) {
        closeAllModals();
      }
    });
  });

  // Escape key close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
    }
  });

  // Switch between Login and Register inside modal
  const toRegisterBtn = document.getElementById('switch-to-register');
  if (toRegisterBtn) {
    toRegisterBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('login-modal');
      openModal('register-modal');
    });
  }

  const toLoginBtn = document.getElementById('switch-to-login');
  if (toLoginBtn) {
    toLoginBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('register-modal');
      openModal('login-modal');
    });
  }

  const forgotBtn = document.getElementById('forgot-password-link');
  if (forgotBtn) {
    forgotBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('login-modal');
      openModal('reset-modal');
    });
  }

  const resetForm = document.getElementById('reset-form');
  if (resetForm) {
    resetForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast(t('auth_reset_modal_desc') + ' (Demo: Emailga yuborildi!)', 'success');
      closeModal('reset-modal');
    });
  }
}

function openModal(modalId, profession = null) {
  closeAllModals();
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';

    // If opening register modal with preselected profession
    if (modalId === 'register-modal' && profession) {
      const profSelect = document.getElementById('reg-profession');
      if (profSelect) {
        profSelect.value = profession;
      }
    }
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('show'));
  document.body.style.overflow = '';
}

// Quick action to join a specific profession from cards
function joinProfession(profKey) {
  openModal('register-modal', profKey);
}

// ===================================================================
// FAQ ACCORDION
// ===================================================================

function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const header = item.querySelector('.faq-header');
    header.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      faqItems.forEach(i => i.classList.remove('active'));
      if (!isActive) {
        item.classList.add('active');
      }
    });
  });
}

// ===================================================================
// MOBILE NAVIGATION
// ===================================================================

function initMobileNav() {
  const hamburger = document.getElementById('hamburger-btn');
  const drawer = document.getElementById('mobile-drawer');
  const closeDrawer = document.getElementById('close-drawer-btn');

  if (hamburger && drawer) {
    hamburger.addEventListener('click', () => {
      drawer.classList.add('open');
    });
  }

  if (closeDrawer && drawer) {
    closeDrawer.addEventListener('click', () => {
      drawer.classList.remove('open');
    });
  }

  // Close when clicking mobile nav links
  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', () => {
      if (drawer) drawer.classList.remove('open');
    });
  });
}

// ===================================================================
// AUTHENTICATION CLIENT LOGIC
// ===================================================================

function initAuthForms() {
  // Register Form
  const regForm = document.getElementById('register-form');
  if (regForm) {
    regForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearErrors(regForm);

      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const password = document.getElementById('reg-password').value;
      const password_confirm = document.getElementById('reg-password-confirm').value;
      const profession = document.getElementById('reg-profession').value;
      const terms = document.getElementById('reg-terms').checked;

      // Client validation
      let hasError = false;

      if (!name) {
        showFieldError('reg-name-error', t('val_name_required'));
        hasError = true;
      }

      const emailRegex = /^[\w\.-]+@[\w\.-]+\.\w+$/;
      if (!email || !emailRegex.test(email)) {
        showFieldError('reg-email-error', t('val_email_invalid'));
        hasError = true;
      }

      if (password.length < 8) {
        showFieldError('reg-password-error', t('val_pass_min'));
        hasError = true;
      }

      if (password !== password_confirm) {
        showFieldError('reg-password-confirm-error', t('val_pass_match'));
        hasError = true;
      }

      if (!profession) {
        showFieldError('reg-profession-error', t('val_prof_required'));
        hasError = true;
      }

      if (!terms) {
        showFieldError('reg-terms-error', t('val_terms_required'));
        hasError = true;
      }

      if (hasError) return;

      const submitBtn = regForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner">⏳</span> ' + t('auth_btn_register') + '...';

      try {
        const res = await fetch('/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password, password_confirm, profession, terms, language: currentLang })
        });

        const data = await res.json();

        if (res.ok && data.success) {
          showToast(t('alert_reg_success'), 'success');
          closeModal('register-modal');
          setTimeout(() => {
            window.location.href = data.redirect || '/dashboard';
          }, 800);
        } else {
          showToast(data.message || t('alert_error_generic'), 'error');
          if (data.field) {
            showFieldError(`reg-${data.field}-error`, data.message);
          }
        }
      } catch (err) {
        showToast(t('alert_error_generic'), 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }

  // Login Form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearErrors(loginForm);

      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;

      if (!email) {
        showFieldError('login-email-error', t('val_email_invalid'));
        return;
      }
      if (!password) {
        showFieldError('login-password-error', t('val_pass_min'));
        return;
      }

      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner">⏳</span> ' + t('auth_btn_login') + '...';

      try {
        const res = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (res.ok && data.success) {
          showToast(t('alert_login_success'), 'success');
          closeModal('login-modal');
          setTimeout(() => {
            window.location.href = data.redirect || '/dashboard';
          }, 800);
        } else {
          showToast(data.message || t('alert_error_generic'), 'error');
          showFieldError('login-email-error', data.message);
        }
      } catch (err) {
        showToast(t('alert_error_generic'), 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }
}

function showFieldError(elId, msg) {
  const el = document.getElementById(elId);
  if (el) {
    el.innerText = msg;
    el.classList.add('visible');
  }
}

function clearErrors(form) {
  form.querySelectorAll('.field-error-msg').forEach(el => {
    el.innerText = '';
    el.classList.remove('visible');
  });
}

// ===================================================================
// WINNERS DATA & DYNAMIC RENDERING
// ===================================================================

let cachedWinners = [];

async function loadWinnersData() {
  try {
    const res = await fetch('/api/winners');
    if (res.ok) {
      cachedWinners = await res.json();
      renderWinnersCards();
    }
  } catch (e) {
    console.error('Error fetching winners:', e);
  }
}

function renderWinnersCards() {
  const container = document.getElementById('winners-container');
  if (!container || !cachedWinners || cachedWinners.length === 0) return;

  const profLabels = {
    web_dev: { uz: 'Web sayt yaratish', ru: 'Веб-разработка', en: 'Web Development' },
    web_design: { uz: 'Web dizayner', ru: 'Веб-дизайнер', en: 'Web Designer' },
    mobilography: { uz: 'Mobilograf', ru: 'Мобилограф', en: 'Mobilographer' }
  };

  const medals = { 1: '🥇', 2: '🥈', 3: '🥉' };
  const ranks = { 1: '1st', 2: '2nd', 3: '3rd' };
  const rings = { 1: 'ring-gold', 2: 'ring-silver', 3: 'ring-bronze' };

  container.innerHTML = cachedWinners.map(w => {
    const profName = (profLabels[w.profession] && profLabels[w.profession][currentLang]) || w.profession;
    const achievement = currentLang === 'ru' ? w.achievement_ru : (currentLang === 'en' ? w.achievement_en : w.achievement);
    const prize = currentLang === 'ru' ? w.prize_ru : (currentLang === 'en' ? w.prize_en : w.prize);
    const rankTitle = currentLang === 'ru' ? `${w.rank}-е место` : (currentLang === 'en' ? `${w.rank}${w.rank===1?'st':w.rank===2?'nd':'rd'} Place` : `${w.rank}-o‘rin`);

    return `
      <div class="glass-card podium-card podium-${w.rank}st">
        <div class="podium-medal">${medals[w.rank]}</div>
        <div class="winner-avatar-ring ${rings[w.rank]}">
          <img src="${w.avatar}" alt="${w.name}" class="winner-avatar-img">
        </div>
        <div class="winner-prof-badge">${profName}</div>
        <h3 class="winner-name">${w.name}</h3>
        <div class="winner-score">🏆 ${t('score_label')} ${w.score} / 100</div>
        <p class="winner-achievement">${achievement}</p>
        <div class="winner-prize-tag">🎁 ${prize}</div>
      </div>
    `;
  }).join('');
}

// ===================================================================
// TOAST NOTIFICATIONS
// ===================================================================

function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span style="font-size: 1.25rem;">${type === 'success' ? '✅' : '⚠️'}</span>
    <span style="flex: 1;">${message}</span>
  `;

  container.appendChild(toast);

  // Trigger animation
  setTimeout(() => toast.classList.add('show'), 50);

  // Auto remove
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// Global logout function
async function logoutUser() {
  try {
    const res = await fetch('/api/logout', { method: 'POST' });
    if (res.ok) {
      window.location.href = '/';
    }
  } catch (e) {
    window.location.href = '/';
  }
}
