import os
import re
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, init_db

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'zamonaviy-kasblar-secret-key-2026-super-secure')

EMAIL_REGEX = r'^[\w\.-]+@[\w\.-]+\.\w+$'

def get_current_user():
    user_id = session.get('user_id')
    if not user_id:
        return None
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    if user:
        return dict(user)
    return None

# ==================== PAGE ROUTES ====================

@app.route('/')
def index():
    user = get_current_user()
    return render_template('index.html', user=user)

@app.route('/login')
def login_page():
    user = get_current_user()
    if user:
        return redirect('/dashboard')
    return render_template('index.html', open_modal='login', user=None)

@app.route('/register')
def register_page():
    user = get_current_user()
    if user:
        return redirect('/dashboard')
    return render_template('index.html', open_modal='register', user=None)

@app.route('/dashboard')
def dashboard():
    user = get_current_user()
    if not user:
        return redirect('/login')
    return render_template('dashboard.html', user=user)

@app.route('/admin')
def admin_page():
    user = get_current_user()
    if not user or user.get('role') != 'admin':
        return redirect('/login')
    return render_template('admin.html', user=user)

# ==================== AUTH API ====================

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json() or {}
    name = (data.get('name') or '').strip()
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''
    password_confirm = data.get('password_confirm') or ''
    profession = data.get('profession') or ''
    lang = data.get('language') or 'uz'
    terms = data.get('terms')

    # Validation
    if not name:
        return jsonify({'success': False, 'message': 'Ism kiritilishi shart!', 'field': 'name'}), 400
    
    if not email or not re.match(EMAIL_REGEX, email):
        return jsonify({'success': False, 'message': 'To‘g‘ri elektron pochta manzilini kiriting!', 'field': 'email'}), 400

    if len(password) < 8:
        return jsonify({'success': False, 'message': 'Parol kamida 8 ta belgidan iborat bo‘lishi kerak!', 'field': 'password'}), 400

    if password != password_confirm:
        return jsonify({'success': False, 'message': 'Parollar mos kelmadi!', 'field': 'password_confirm'}), 400

    valid_professions = ['web_dev', 'web_design', 'mobilography']
    if profession not in valid_professions:
        return jsonify({'success': False, 'message': 'Iltimos, kasb yo‘nalishini tanlang!', 'field': 'profession'}), 400

    if not terms:
        return jsonify({'success': False, 'message': 'Tanlov qoidalariga rozilik bildirish shart!', 'field': 'terms'}), 400

    conn = get_db()
    existing = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if existing:
        conn.close()
        return jsonify({'success': False, 'message': 'Bu email orqali allaqachon ro‘yxatdan o‘tilgan!', 'field': 'email'}), 400

    password_hash = generate_password_hash(password)
    now = datetime.now().isoformat()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO users (name, email, password_hash, profession, language, role, competition_status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'user', 'registered', ?, ?)
    ''', (name, email, password_hash, profession, lang, now, now))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()

    session['user_id'] = user_id

    return jsonify({
        'success': True,
        'message': 'Tabriklaymiz! Muvaffaqiyatli ro‘yxatdan o‘tdingiz.',
        'user': {
            'id': user_id,
            'name': name,
            'email': email,
            'profession': profession,
            'language': lang,
            'role': 'user'
        },
        'redirect': '/dashboard'
    })

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json() or {}
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''

    if not email:
        return jsonify({'success': False, 'message': 'Email kiritilishi shart!', 'field': 'email'}), 400
    if not password:
        return jsonify({'success': False, 'message': 'Parol kiritilishi shart!', 'field': 'password'}), 400

    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()

    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify({'success': False, 'message': 'Email yoki parol noto‘g‘ri!'}), 401

    session['user_id'] = user['id']

    return jsonify({
        'success': True,
        'message': 'Tizimga muvaffaqiyatli kirdingiz!',
        'user': {
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'profession': user['profession'],
            'language': user['language'],
            'role': user['role']
        },
        'redirect': '/admin' if user['role'] == 'admin' else '/dashboard'
    })

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.pop('user_id', None)
    return jsonify({'success': True, 'message': 'Tizimdan chiqildi', 'redirect': '/'})

@app.route('/api/me')
def api_me():
    user = get_current_user()
    if not user:
        return jsonify({'authenticated': False}), 401
    
    # Do not expose password_hash
    user_safe = dict(user)
    user_safe.pop('password_hash', None)
    return jsonify({'authenticated': True, 'user': user_safe})

# ==================== USER PROFILE & SUBMISSION API ====================

@app.route('/api/profile', methods=['PUT'])
def api_update_profile():
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'message': 'Avtorizatsiyadan o‘tilmagan!'}), 401

    data = request.get_json() or {}
    name = (data.get('name') or user['name']).strip()
    email = (data.get('email') or user['email']).strip().lower()
    profession = data.get('profession') or user['profession']
    phone = data.get('phone') or user.get('phone', '')
    telegram = data.get('telegram') or user.get('telegram', '')
    new_password = data.get('password')
    language = data.get('language') or user.get('language', 'uz')

    if not name:
        return jsonify({'success': False, 'message': 'Ism bo‘sh bo‘lishi mumkin emas!'}), 400
    if not email or not re.match(EMAIL_REGEX, email):
        return jsonify({'success': False, 'message': 'Noto‘g‘ri email formati!'}), 400

    conn = get_db()
    if email != user['email']:
        existing = conn.execute("SELECT id FROM users WHERE email = ? AND id != ?", (email, user['id'])).fetchone()
        if existing:
            conn.close()
            return jsonify({'success': False, 'message': 'Ushbu email boshqa foydalanuvchi tomonidan band qilingan!'}), 400

    now = datetime.now().isoformat()
    if new_password and len(new_password) >= 8:
        new_hash = generate_password_hash(new_password)
        conn.execute('''
            UPDATE users 
            SET name = ?, email = ?, profession = ?, phone = ?, telegram = ?, language = ?, password_hash = ?, updated_at = ?
            WHERE id = ?
        ''', (name, email, profession, phone, telegram, language, new_hash, now, user['id']))
    else:
        conn.execute('''
            UPDATE users 
            SET name = ?, email = ?, profession = ?, phone = ?, telegram = ?, language = ?, updated_at = ?
            WHERE id = ?
        ''', (name, email, profession, phone, telegram, language, now, user['id']))

    conn.commit()
    updated = conn.execute("SELECT * FROM users WHERE id = ?", (user['id'],)).fetchone()
    conn.close()

    updated_safe = dict(updated)
    updated_safe.pop('password_hash', None)

    return jsonify({
        'success': True,
        'message': 'Profilingiz muvaffaqiyatli yangilandi!',
        'user': updated_safe
    })

@app.route('/api/submit-task', methods=['POST'])
def api_submit_task():
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'message': 'Avtorizatsiyadan o‘tilmagan!'}), 401

    data = request.get_json() or {}
    url = (data.get('submission_url') or '').strip()
    notes = (data.get('submission_notes') or '').strip()

    if not url:
        return jsonify({'success': False, 'message': 'Iltimos, loyihangiz havolasini (GitHub, Figma yoki Google Drive) kiriting!'}), 400

    now = datetime.now().isoformat()
    conn = get_db()
    conn.execute('''
        UPDATE users
        SET task_submission_url = ?, task_submission_notes = ?, task_submitted_at = ?, competition_status = 'task_submitted', updated_at = ?
        WHERE id = ?
    ''', (url, notes, now, now, user['id']))
    conn.commit()
    conn.close()

    return jsonify({
        'success': True,
        'message': 'Topshiriq muvaffaqiyatli yuborildi! Hakamlar hay’ati ko‘rib chiqadi.'
    })

# ==================== GENERAL & ADMIN API ====================

@app.route('/api/stats')
def api_stats():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM users WHERE role = 'user'").fetchone()[0]
    web_dev = conn.execute("SELECT COUNT(*) FROM users WHERE profession = 'web_dev' AND role = 'user'").fetchone()[0]
    web_design = conn.execute("SELECT COUNT(*) FROM users WHERE profession = 'web_design' AND role = 'user'").fetchone()[0]
    mobilography = conn.execute("SELECT COUNT(*) FROM users WHERE profession = 'mobilography' AND role = 'user'").fetchone()[0]
    submitted = conn.execute("SELECT COUNT(*) FROM users WHERE task_submission_url IS NOT NULL AND role = 'user'").fetchone()[0]
    conn.close()

    return jsonify({
        'total_participants': total,
        'web_dev': web_dev,
        'web_design': web_design,
        'mobilography': mobilography,
        'submissions': submitted
    })

@app.route('/api/winners')
def api_winners():
    conn = get_db()
    rows = conn.execute("SELECT * FROM winners ORDER BY rank ASC").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/admin/participants')
def api_admin_participants():
    user = get_current_user()
    if not user or user.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    profession = request.args.get('profession')
    search = request.args.get('search', '').strip()

    query = "SELECT id, name, email, profession, phone, telegram, competition_status, task_submission_url, task_submission_notes, task_submitted_at, score, jury_feedback, created_at FROM users WHERE role = 'user'"
    params = []

    if profession and profession != 'all':
        query += " AND profession = ?"
        params.append(profession)

    if search:
        query += " AND (name LIKE ? OR email LIKE ?)"
        params.append(f"%{search}%")
        params.append(f"%{search}%")

    query += " ORDER BY created_at DESC"

    conn = get_db()
    rows = conn.execute(query, params).fetchall()
    conn.close()

    return jsonify([dict(r) for r in rows])

@app.route('/api/admin/grade', methods=['POST'])
def api_admin_grade():
    user = get_current_user()
    if not user or user.get('role') != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    data = request.get_json() or {}
    participant_id = data.get('participant_id')
    score = data.get('score')
    feedback = data.get('feedback', '')
    status = data.get('status', 'evaluated')

    conn = get_db()
    now = datetime.now().isoformat()
    conn.execute('''
        UPDATE users
        SET score = ?, jury_feedback = ?, competition_status = ?, updated_at = ?
        WHERE id = ?
    ''', (score, feedback, status, now, participant_id))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': 'Baholash saqlandi!'})

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
