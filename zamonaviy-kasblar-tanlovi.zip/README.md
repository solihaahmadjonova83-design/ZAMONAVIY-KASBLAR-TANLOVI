# 🚀 ZAMONAVIY KASBLAR TANLOVI — 2026

> **“Kelajak kasbini tanla. O‘z imkoniyatingni namoyon qil.”**

Zamonaviy, premium, yuqori darajada xavfsiz va to'liq interaktiv raqamli tanlov veb-platformasi. Loyiha O'zbekiston yoshlari o'rtasida 3 ta eng talabgir kasb: **Web sayt yaratish**, **Web dizayner** va **Mobilograf** yo'nalishlarida ochiq chempionatni tashkil qilish uchun ishlab chiqilgan.

---

## 🌟 Asosiy Xususiyatlar (Key Features)

### 1. Vizual Dizayn va Texnologik Ekotizim
- **Deep Navy & Cyber Dark Theme**: `#070913` chuqur kosmik qora fon, neon elektr ko'k (`#00F2FE`), siyohrang (`#A855F7`) va havorang (`#38BDF8`) gradientlari.
- **Glassmorphism 2.0**: Nozik yarim shaffof kartalar (`backdrop-filter: blur(16px)`), dinamik nurli chegaralar va mikro-animatsiyalar.
- **Interaktiv Canvas Zarrachalar (Particles)**: Sichqoncha harakatiga moslashuvchi va fon yorug'lik effektlarini yaratuvchi maxsus canvas dvigateli.
- **Podium G'oliblar Tizimi**: Oltin 🥇, Kumush 🥈 va Bronza 🥉 medalli podium animatsiyalari, ballar va yutuqlar ko'rsatkichi.
- **To'liq Moslashuvchan (Responsive UX)**: Desktop, noutbuk, planshet va mobil smartfonlar uchun maxsus moslashtirilgan menyu (Hamburger drawer).

### 2. Uchta Zamonaviy Kasb (3 Modern Professions)
1. **Web sayt yaratish** (HTML, CSS, JavaScript, UI/UX, Responsive Design)
2. **Web dizayner** (UI/UX, Figma, Typography, Color, Layout, Prototyping)
3. **Mobilograf** (Video, Mobile photography, Editing, Reels, Storytelling, Creative Content)

### 3. Ko'p Tillilik Tizimi (3 Languages: UZ / RU / EN)
- 🇺🇿 **O‘zbekcha** (Standart til)
- 🇷🇺 **Русский**
- 🇬🇧 **English**
- Bir tugma orqali sahifani qayta yuklamasdan barcha matnlar, xabarlar, modal oynalar, validatsiya xatolari va shaxsiy kabinet dinamik tarjima qilinadi.

### 4. Haqiqiy Autentifikatsiya va SQLite Ma'lumotlar Bazasi
- Ro'yxatdan o'tish (`/api/register`) va Kirish (`/api/login`).
- Parollarni xavfsiz shifrlash (`Werkzeug pbkdf2/scrypt` xesh).
- Sessiyalarni xavfsiz boshqarish (Signed cookie sessions).
- Forma validatsiyasi (Email regex, parol kamida 8 belgi, tasdiqlash tekshiruvi, majburiy shartlar).

### 5. Foydalanuvchi Shaxsiy Kabineti (`/dashboard`)
- Ishtirokchi ma'lumotlari va profil to'ldirilish foizi.
- **4 ta asosiy karta**:
  1. **Mening yo'nalishim**: Tanlangan kasb bo'yicha maxsus talablar va ko'rsatmalar.
  2. **Tanlov holati**: 4 bosqichli holat indikatori (Ro'yxatdan o'tish -> Kasb tanlash -> Topshiriq -> Natija).
  3. **Topshiriqlar**: GitHub / Figma / Google Drive havolasini topshirish va izoh yozish formasi.
  4. **Natijalar**: Hakamlar ballari, fikr-mulohazalari va elektron sertifikat.
- **Profil sozlamalari**: Ism, email, kasb, telefon, telegram va yangi parolni yangilash.

### 6. Administrator Paneli (`/admin`)
- Jonli telemetriya va statistika (Jami ishtirokchilar, yo'nalishlar kesimi, topshirilgan ishlar).
- Qidiruv va yo'nalish bo'yicha filtrlash.
- Ishtirokchilar topshiriqlarini ko'rish va 100 ballik tizimda baholash (izoh va ball bilan).

---

## 🛠 O'rnatish va Ishga Tushirish (Quick Start)

### Talablar:
- Python 3.10+ (tizimda mavjud: Python 3.13.1)
- Flask

### Ishga tushirish qadamlari:

```powershell
# 1. Loyiha papkasiga o'ting
cd "C:\Users\Monomarkaz-12\.gemini\antigravity\scratch\zamonaviy-kasblar"

# 2. Ma'lumotlar bazasini ishga tushirish (agar hali qilinmagan bo'lsa)
python database.py

# 3. Serverni yoqish
python app.py
```

Server ishga tushgach, brauzeringizda quyidagi manzilni oching:
👉 **`http://localhost:5000`**

---

## 🔑 Standart Tizim Hisoblari (Default Accounts)

1. **Bosh Administrator**:
   - **Email:** `admin@kasblar.uz`
   - **Parol:** `Admin2026!`
   - **Ruxsat:** Barcha ishtirokchilarni ko'rish, qidirish, filtrlash va baholash.

2. **Yangi Ishtirokchi**:
   - Istalgan email bilan to'g'ridan-to'g'ri ro'yxatdan o'tishingiz mumkin (Masalan: `siz@example.uz` / `Parol2026!`).

---

## 📁 Loyiha Tuzilmasi

```
zamonaviy-kasblar/
├── app.py                   # Flask server, API marshrutlari va avtorizatsiya
├── database.py              # SQLite sxemasi, jadvallar va dastlabki ma'lumotlar
├── kasblar.db               # SQLite ma'lumotlar bazasi fayli
├── test_platform.py         # 10 ta avtomatlashtirilgan backend testi
├── templates/
│   ├── index.html           # Asosiy landing page (Barcha bo'limlar va modallar)
│   ├── dashboard.html       # Shaxsiy kabinet (4 ta karta, topshiriq topshirish, sozlamalar)
│   └── admin.html           # Boshqaruv paneli (Statistika, qidiruv, baholash)
└── static/
    ├── css/
    │   └── style.css        # Premium Cyber-Glassmorphism CSS uslublar tizimi
    └── js/
        ├── translations.js  # 3 tilli to'liq lug'at (UZ, RU, EN)
        ├── particles.js     # Interaktiv fon zarrachalari canvas dvigateli
        ├── app.js           # Asosiy mijoz skripti (Tarjima, modal, forma validatsiyasi)
        ├── dashboard.js     # Shaxsiy kabinet mantiqi (Topshiriq va profil boshqaruvi)
        └── admin.js         # Admin paneli (Qidiruv, filtrlash, baholash)
```
