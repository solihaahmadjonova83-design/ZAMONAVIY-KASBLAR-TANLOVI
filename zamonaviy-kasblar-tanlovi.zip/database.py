import sqlite3
import os
from werkzeug.security import generate_password_hash
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'kasblar.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        profession TEXT NOT NULL,
        language TEXT DEFAULT 'uz',
        role TEXT DEFAULT 'user',
        phone TEXT,
        telegram TEXT,
        competition_status TEXT DEFAULT 'registered',
        task_submission_url TEXT,
        task_submission_notes TEXT,
        task_submitted_at TEXT,
        score REAL DEFAULT NULL,
        jury_feedback TEXT DEFAULT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Create winners table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS winners (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        rank INTEGER NOT NULL,
        name TEXT NOT NULL,
        profession TEXT NOT NULL,
        score REAL NOT NULL,
        achievement TEXT NOT NULL,
        achievement_ru TEXT NOT NULL,
        achievement_en TEXT NOT NULL,
        prize TEXT NOT NULL,
        prize_ru TEXT NOT NULL,
        prize_en TEXT NOT NULL,
        avatar TEXT,
        year INTEGER DEFAULT 2026
    )
    ''')

    # Seed Admin if not exists
    cursor.execute("SELECT id FROM users WHERE email = ?", ('admin@kasblar.uz',))
    admin = cursor.fetchone()
    if not admin:
        admin_pass = generate_password_hash('Admin2026!')
        now = datetime.now().isoformat()
        cursor.execute('''
            INSERT INTO users (name, email, password_hash, profession, language, role, competition_status, score, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ('Bosh Administrator', 'admin@kasblar.uz', admin_pass, 'web_dev', 'uz', 'admin', 'verified', 100, now, now))

    # Seed sample participants for realistic demonstration
    sample_users = [
        ('Sardor Rahimqulov', 'sardor@example.uz', 'web_dev', 'task_submitted', 'https://github.com/sardor/edu-modern-platform', 'To''liq responsive Next.js web platformasi yaratildi.', 94.0),
        ('Laylo Azimova', 'laylo@example.uz', 'web_design', 'task_submitted', 'https://figma.com/@laylo/kasblar-design-system', 'To''liq UI/UX dizayn tizimi va mobil adaptatsiya tayyorlandi.', 97.5),
        ('Bobur Mirzayev', 'bobur@example.uz', 'mobilography', 'task_submitted', 'https://drive.google.com/sample/mobilography-reels', '4K sifatdagi kinematik rolik va rang korreksiyasi bilan montaj.', 91.0),
        ('Malika Rustamova', 'malika@example.uz', 'web_design', 'registered', None, None, None),
        ('Azizbek Tursunov', 'aziz@example.uz', 'web_dev', 'registered', None, None, None),
        ('Shaxzod Normatov', 'shaxzod@example.uz', 'mobilography', 'registered', None, None, None)
    ]

    for name, email, prof, status, sub_url, sub_notes, score in sample_users:
        cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
        if not cursor.fetchone():
            p_hash = generate_password_hash('Kasblar2026!')
            now = datetime.now().isoformat()
            cursor.execute('''
                INSERT INTO users (name, email, password_hash, profession, language, role, competition_status, task_submission_url, task_submission_notes, task_submitted_at, score, created_at, updated_at)
                VALUES (?, ?, ?, ?, 'uz', 'user', ?, ?, ?, ?, ?, ?, ?)
            ''', (name, email, p_hash, prof, status, sub_url, sub_notes, now if sub_url else None, score, now, now))

    # Seed winners if empty
    cursor.execute("SELECT COUNT(*) FROM winners")
    if cursor.fetchone()[0] == 0:
        winners_data = [
            (
                1,
                "Jasur Beknazarov",
                "web_dev",
                98.5,
                "Next-gen AI ta'lim platformasi ekotizimini to'liq ishlab chiqqani va yuqori tezlik ko'rsatkichi uchun",
                "За разработку экосистемы образовательной ИИ-платформы следующего поколения и высокую производительность",
                "For developing a next-gen AI educational platform ecosystem with ultra-fast performance",
                "Apple MacBook Pro M3 + 30 000 000 UZS",
                "Apple MacBook Pro M3 + 30 000 000 UZS",
                "Apple MacBook Pro M3 + 30 000 000 UZS",
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
            ),
            (
                2,
                "Madina Karimova",
                "web_design",
                96.0,
                "Fintech ekotizimi uchun qulay, intuitiv dizayn tizimi va interaktiv 3D prototipi uchun",
                "За интуитивную дизайн-систему финтех-экосистемы и интерактивный 3D-прототип",
                "For an intuitive Fintech design system and interactive 3D prototype",
                "Apple iPhone 16 Pro + 20 000 000 UZS",
                "Apple iPhone 16 Pro + 20 000 000 UZS",
                "Apple iPhone 16 Pro + 20 000 000 UZS",
                "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80"
            ),
            (
                3,
                "Temur Olimov",
                "mobilography",
                94.2,
                "Toshkent zamonaviy arxitekturasi va yoshlariga bag'ishlangan kinematografik 4K reels turkumi uchun",
                "За кинематографическую серию 4K reels о современной архитектуре и молодежи Ташкента",
                "For a cinematic 4K reels series showcasing Tashkent's modern architecture and youth",
                "Apple iPad Air M2 + 10 000 000 UZS",
                "Apple iPad Air M2 + 10 000 000 UZS",
                "Apple iPad Air M2 + 10 000 000 UZS",
                "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
            )
        ]

        for w in winners_data:
            cursor.execute('''
                INSERT INTO winners (rank, name, profession, score, achievement, achievement_ru, achievement_en, prize, prize_ru, prize_en, avatar)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', w)

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully!")
