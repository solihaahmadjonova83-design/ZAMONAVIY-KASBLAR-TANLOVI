import sys
sys.stdout.reconfigure(encoding='utf-8')

import urllib.request
import urllib.parse
import json
import http.cookiejar
import time

base_url = 'http://127.0.0.1:5000'
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

# 1. Test GET /
resp = opener.open(f'{base_url}/')
assert resp.status == 200
html = resp.read().decode('utf-8')
assert 'ZAMONAVIY KASBLAR TANLOVI' in html
print('[PASS] GET / successfully passed!')

# 2. Test GET /api/stats
resp = opener.open(f'{base_url}/api/stats')
assert resp.status == 200
stats = json.loads(resp.read().decode('utf-8'))
assert 'total_participants' in stats
print(f'[PASS] GET /api/stats passed: {stats}')

# 3. Test GET /api/winners
resp = opener.open(f'{base_url}/api/winners')
assert resp.status == 200
winners = json.loads(resp.read().decode('utf-8'))
assert len(winners) == 3
print(f'[PASS] GET /api/winners passed: {len(winners)} winners found')

# 4. Test Registration Validation (invalid case: short password)
reg_bad_payload = json.dumps({
    'name': 'Test User',
    'email': 'badpass@example.com',
    'password': '123',
    'password_confirm': '123',
    'profession': 'web_dev',
    'terms': True
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/register', data=reg_bad_payload, headers={'Content-Type': 'application/json'})
try:
    opener.open(req)
    print('Failed: expected 400 for short password')
except urllib.error.HTTPError as e:
    assert e.code == 400
    print('[PASS] Registration validation for short password verified!')

# 5. Test Successful Registration
unique_email = f'alisher_{int(time.time())}@example.uz'
reg_good_payload = json.dumps({
    'name': 'Alisher Navoiy',
    'email': unique_email,
    'password': 'SecurePassword2026!',
    'password_confirm': 'SecurePassword2026!',
    'profession': 'web_dev',
    'terms': True,
    'language': 'uz'
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/register', data=reg_good_payload, headers={'Content-Type': 'application/json'})
resp = opener.open(req)
assert resp.status == 200
reg_res = json.loads(resp.read().decode('utf-8'))
assert reg_res['success'] is True
print(f'[PASS] Registration succeeded for {unique_email}!')

# 6. Test GET /api/me with session
resp = opener.open(f'{base_url}/api/me')
assert resp.status == 200
me_data = json.loads(resp.read().decode('utf-8'))
assert me_data['authenticated'] is True
user_name = me_data['user']['name']
print(f'[PASS] Authenticated session verified for: {user_name}')

# 7. Test Task Submission
sub_payload = json.dumps({
    'submission_url': 'https://github.com/alisher/future-web-project',
    'submission_notes': 'Kreativ veb ilova ishlab chiqildi, Tailwind va Next.js ishlatildi.'
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/submit-task', data=sub_payload, headers={'Content-Type': 'application/json'})
resp = opener.open(req)
assert resp.status == 200
print('[PASS] Task submission verified!')

# 8. Test Profile Update
prof_payload = json.dumps({
    'name': 'Alisher Navoiy (Yangilangan)',
    'phone': '+998901234567',
    'telegram': '@alisher_dev'
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/profile', data=prof_payload, headers={'Content-Type': 'application/json'})
req.get_method = lambda: 'PUT'
resp = opener.open(req)
assert resp.status == 200
prof_res = json.loads(resp.read().decode('utf-8'))
assert prof_res['user']['name'] == 'Alisher Navoiy (Yangilangan)'
print('[PASS] Profile update verified!')

# 9. Test Admin Login and Grading
admin_cj = http.cookiejar.CookieJar()
admin_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(admin_cj))
login_payload = json.dumps({
    'email': 'admin@kasblar.uz',
    'password': 'Admin2026!'
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/login', data=login_payload, headers={'Content-Type': 'application/json'})
resp = admin_opener.open(req)
assert resp.status == 200
admin_res = json.loads(resp.read().decode('utf-8'))
assert admin_res['user']['role'] == 'admin'
print('[PASS] Admin login verified!')

# 10. Admin Grade Participant
grade_payload = json.dumps({
    'participant_id': me_data['user']['id'],
    'score': 95.5,
    'feedback': 'Ajoyib arxitektura va yuqori darajadagi UI dizayn!'
}).encode('utf-8')
req = urllib.request.Request(f'{base_url}/api/admin/grade', data=grade_payload, headers={'Content-Type': 'application/json'})
resp = admin_opener.open(req)
assert resp.status == 200
print('[PASS] Participant evaluation & grading verified!')

print('\n>>> ALL SYSTEM & AUTHENTICATION TESTS PASSED WITH 100% SUCCESS! <<<')
