# ⚡ ZAMONAVIY KASBLAR TANLOVI — 2026 (Pure HTML, CSS, JavaScript)

> **“Kelajak kasbini tanla. O‘z imkoniyatingni namoyon qil.”**

Bu loyiha **100% toza HTML, CSS va JavaScript (Frontend-only)** tilida yaratilgan.
Hech qanday Python, Node.js yoki server talab qilinmaydi! **GitHub Pages**da 1 marta bosish bilan to'g'ridan-to'g'ri ishga tushadi.

---

## 🌟 Qanday ishga tushiriladi?

### 1. Kompyuterda ochish:
Shunchaki `index.html` faylini istalgan brauzerda (Chrome, Edge, Safari, Firefox) ikki marta bosib oching.

### 2. GitHub Pages'da bepul jonli sayt qilish:
1. Ushbu loyiha fayllarini GitHub repositoriyangizga yuklang (`index.html` asosiy ildizda bo'lishi lozim).
2. GitHub'da **Settings** bo'limiga o'ting.
3. Chap menyudan **Pages** tugmasini bosing.
4. **Branch** bo'limidan `main` (yoki `master`) tanlab, **Save** tugmasini bosing.
5. 1 daqiqa ichida saytingiz jonli efirga chiqadi (masalan: `https://username.github.io/repo-nomi/`)!

---

## 🔑 Sinov Uchun Tayyor Hisoblar (Pre-configured Test Accounts)

1. **Bosh Administrator:**
   - **Email:** `admin@kasblar.uz`
   - **Parol:** `Admin2026!`
   *(Ishtirokchilarni ko'rish, qidirish, filtr qilish va ularga ball qo'yish imkoniyati)*

2. **Oddiy Ishtirokchi:**
   - "Ro'yxatdan o'tish" tugmasini bosib istalgan yangi hisob yarating yoki mavjud test hisobiga kiring:
   - **Email:** `sardor@example.uz`
   - **Parol:** `Kasblar2026!`

---

## 📁 Fayllar Tuzilishi:
```text
├── index.html           # Asosiy sahifa, Shaxsiy kabinet, Admin panel va barcha modallar
├── css/
│   └── style.css        # Cyber-Glassmorphism CSS dizayn tizimi
└── js/
    ├── translations.js  # 3 tilli lug'at (UZ, RU, EN)
    ├── particles.js     # Interaktiv fon zarrachalari canvas dvigateli
    ├── storage.js       # Brauzer localStorage xotirasidagi ma'lumotlar bazasi
    └── app.js           # Asosiy interaktiv logika va sahifalar boshqaruvi
```
