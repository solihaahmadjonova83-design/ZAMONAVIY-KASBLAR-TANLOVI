// ZAMONAVIY KASBLAR TANLOVI - PURE JAVASCRIPT APPLICATION ENGINE
let currentLang = localStorage.getItem('zk_lang') || 'uz';
let currentView = 'home'; // 'home' | 'dashboard' | 'admin'
let selectedParticipantId = null;

document.addEventListener('DOMContentLoaded', () => {
  initLanguage();
  initModals();
  initFaqAccordion();
  initMobileNav();
  initAuth();
  initDashboardForms();
  initAdminView();
  renderWinners();
  updateAuthUI();

  // Route handling via hash (#home, #dashboard, #admin)
  window.addEventListener('hashchange', handleHashRouting);
  handleHashRouting();
});

// ===================================================================
// HASH ROUTING & VIEW SWITCHING
// ===================================================================

function switchView(viewName) {
  currentView = viewName;

  const homeSection = document.getElementById('view-home');
  const dashSection = document.getElementById('view-dashboard');
  const adminSection = document.getElementById('view-admin');

  if (viewName === 'dashboard') {
    const user = DB.getCurrentUser();
    if (!user) {
      openModal('login-modal');
      return;
    }
    if (homeSection) homeSection.style.display = 'none';
    if (adminSection) adminSection.style.display = 'none';
    if (dashSection) dashSection.style.display = 'block';
    renderDashboard();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'admin') {
    const user = DB.getCurrentUser();
    if (!user || user.role !== 'admin') {
      showToast('Admin huquqi talab qilinadi! (admin@kasblar.uz / Admin2026!)', 'error');
      openModal('login-modal');
      return;
    }
    if (homeSection) homeSection.style.display = 'none';
    if (dashSection) dashSection.style.display = 'none';
    if (adminSection) adminSection.style.display = 'block';
    renderAdminTable();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else {
    // Home view
    if (dashSection) dashSection.style.display = 'none';
    if (adminSection) adminSection.style.display = 'none';
    if (homeSection) homeSection.style.display = 'block';
  }

  updateAuthUI();
}

function handleHashRouting() {
  const hash = window.location.hash;
  if (hash === '#dashboard') {
    switchView('dashboard');
  } else if (hash === '#admin') {
    switchView('admin');
  } else {
    switchView('home');
  }
}

// ===================================================================
// MULTILINGUAL SYSTEM
// ===================================================================

function initLanguage() {
  setLanguage(currentLang);

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute('data-lang');
      setLanguage(lang);
    });
  });
}

function setLanguage(lang) {
  if (!TRANSLATIONS[lang]) return;
  currentLang = lang;
  localStorage.setItem('zk_lang', lang);

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
  });

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (TRANSLATIONS[lang][key] !== undefined) {
      el.innerHTML = TRANSLATIONS[lang][key];
    }
  });

  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const key = el.getAttribute('data-i18n-ph');
    if (TRANSLATIONS[lang][key] !== undefined) {
      el.placeholder = TRANSLATIONS[lang][key];
    }
  });

  renderWinners();
  if (currentView === 'dashboard') renderDashboard();
  if (currentView === 'admin') renderAdminTable();
}

function t(key) {
  return (TRANSLATIONS[currentLang] && TRANSLATIONS[currentLang][key]) || key;
}

// ===================================================================
// AUTHENTICATION & UI SYNC
// ===================================================================

function updateAuthUI() {
  const user = DB.getCurrentUser();
  const guestNav = document.getElementById('nav-guest-actions');
  const userNav = document.getElementById('nav-user-actions');
  const userDrawerNav = document.getElementById('drawer-user-actions');
  const guestDrawerNav = document.getElementById('drawer-guest-actions');

  if (user) {
    if (guestNav) guestNav.style.display = 'none';
    if (userNav) userNav.style.display = 'flex';
    if (guestDrawerNav) guestDrawerNav.style.display = 'none';
    if (userDrawerNav) userDrawerNav.style.display = 'flex';

    const userNameDisplay = document.getElementById('nav-user-name');
    if (userNameDisplay) userNameDisplay.textContent = user.name.split(' ')[0];

    const adminBtn = document.getElementById('nav-admin-btn');
    if (adminBtn) adminBtn.style.display = user.role === 'admin' ? 'inline-flex' : 'none';
  } else {
    if (guestNav) guestNav.style.display = 'flex';
    if (userNav) userNav.style.display = 'none';
    if (guestDrawerNav) guestDrawerNav.style.display = 'flex';
    if (userDrawerNav) userDrawerNav.style.display = 'none';
  }
}

function initAuth() {
  // Register Form
  const regForm = document.getElementById('register-form');
  if (regForm) {
    regForm.addEventListener('submit', (e) => {
      e.preventDefault();
      clearErrors(regForm);

      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const password = document.getElementById('reg-password').value;
      const passwordConfirm = document.getElementById('reg-password-confirm').value;
      const profession = document.getElementById('reg-profession').value;
      const terms = document.getElementById('reg-terms').checked;

      let hasError = false;
      if (!name) { showFieldError('reg-name-error', t('val_name_required')); hasError = true; }
      const emailRegex = /^[\w\.-]+@[\w\.-]+\.\w+$/;
      if (!email || !emailRegex.test(email)) { showFieldError('reg-email-error', t('val_email_invalid')); hasError = true; }
      if (password.length < 8) { showFieldError('reg-password-error', t('val_pass_min')); hasError = true; }
      if (password !== passwordConfirm) { showFieldError('reg-password-confirm-error', t('val_pass_match')); hasError = true; }
      if (!profession) { showFieldError('reg-profession-error', t('val_prof_required')); hasError = true; }
      if (!terms) { showFieldError('reg-terms-error', t('val_terms_required')); hasError = true; }

      if (hasError) return;

      const res = DB.register({ name, email, password, profession });
      if (res.success) {
        showToast(t('alert_reg_success'), 'success');
        closeModal('register-modal');
        regForm.reset();
        window.location.hash = '#dashboard';
        switchView('dashboard');
      } else {
        showToast(res.message, 'error');
        if (res.field) showFieldError(`reg-${res.field}-error`, res.message);
      }
    });
  }

  // Login Form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      clearErrors(loginForm);

      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;

      if (!email) { showFieldError('login-email-error', t('val_email_invalid')); return; }
      if (!password) { showFieldError('login-password-error', t('val_pass_min')); return; }

      const res = DB.login(email, password);
      if (res.success) {
        showToast(t('alert_login_success'), 'success');
        closeModal('login-modal');
        loginForm.reset();
        if (res.user.role === 'admin') {
          window.location.hash = '#admin';
          switchView('admin');
        } else {
          window.location.hash = '#dashboard';
          switchView('dashboard');
        }
      } else {
        showToast(res.message, 'error');
        showFieldError('login-email-error', res.message);
      }
    });
  }

  // Demo Admin Fill Button
  const demoAdminBtn = document.getElementById('demo-admin-login');
  if (demoAdminBtn) {
    demoAdminBtn.addEventListener('click', (e) => {
      e.preventDefault();
      document.getElementById('login-email').value = 'admin@kasblar.uz';
      document.getElementById('login-password').value = 'Admin2026!';
    });
  }
}

function logoutUser() {
  DB.logout();
  showToast('Tizimdan chiqildi', 'success');
  window.location.hash = '#home';
  switchView('home');
}

// ===================================================================
// USER DASHBOARD LOGIC
// ===================================================================

function renderDashboard() {
  const user = DB.getCurrentUser();
  if (!user) return;

  // Header banner info
  document.getElementById('dash-user-name').textContent = user.name;
  document.getElementById('dash-user-email').textContent = user.email;
  document.getElementById('dash-avatar-initial').textContent = user.name.charAt(0).toUpperCase();

  // Profession badge
  const profNames = {
    web_dev: { uz: '💻 Web sayt yaratish', ru: '💻 Веб-разработка', en: '💻 Website Development' },
    web_design: { uz: '🎨 Web dizayner', ru: '🎨 Веб-дизайнер', en: '🎨 Web Designer' },
    mobilography: { uz: '📱 Mobilograf', ru: '📱 Мобилограф', en: '📱 Mobilographer' }
  };
  const profBadge = document.getElementById('dash-profession-badge');
  if (profBadge) {
    profBadge.textContent = (profNames[user.profession] && profNames[user.profession][currentLang]) || user.profession;
  }

  // Status badge
  const statusMap = {
    registered: { uz: '⏳ Ro‘yxatdan o‘tilgan', ru: '⏳ Зарегистрирован', en: '⏳ Registered', color: 'badge-blue' },
    task_submitted: { uz: '📤 Topshiriq yuborilgan', ru: '📤 Работа отправлена', en: '📤 Task Submitted', color: 'badge-amber' },
    under_review: { uz: '🔍 Hakamlar tekshiruvida', ru: '🔍 На проверке', en: '🔍 Under Review', color: 'badge-purple' },
    evaluated: { uz: '✅ Baholangan', ru: '✅ Оценено', en: '✅ Evaluated', color: 'badge-emerald' }
  };
  const curStatus = statusMap[user.competition_status] || statusMap.registered;
  const statusBadge = document.getElementById('dash-status-badge');
  if (statusBadge) {
    statusBadge.textContent = curStatus[currentLang] || curStatus.uz;
    statusBadge.className = `status-pill ${curStatus.color}`;
  }

  // Progress Bar
  let progress = 35;
  if (user.phone || user.telegram) progress += 15;
  if (user.task_submission_url) progress += 30;
  if (user.score !== null) progress = 100;

  document.getElementById('profile-prog-bar').style.width = `${progress}%`;
  document.getElementById('profile-prog-val').textContent = `${progress}%`;

  // Pre-fill profile settings
  document.getElementById('settings-name').value = user.name || '';
  document.getElementById('settings-email').value = user.email || '';
  document.getElementById('settings-profession').value = user.profession || 'web_dev';
  document.getElementById('settings-phone').value = user.phone || '';
  document.getElementById('settings-telegram').value = user.telegram || '';

  // Task form
  const subUrlInput = document.getElementById('task-submission-url');
  const subNotesInput = document.getElementById('task-submission-notes');
  const taskNotice = document.getElementById('task-status-notice');

  if (subUrlInput) subUrlInput.value = user.task_submission_url || '';
  if (subNotesInput) subNotesInput.value = user.task_submission_notes || '';
  if (taskNotice) taskNotice.style.display = user.task_submission_url ? 'block' : 'none';

  // Results display
  const resultsBox = document.getElementById('results-score-display');
  if (resultsBox) {
    if (user.score !== null && user.score !== undefined) {
      resultsBox.innerHTML = `
        <div class="score-number-big">${user.score} / 100</div>
        <p class="score-feedback">"${user.jury_feedback || 'Yuqori sifatli va zamonaviy ijro!'}"</p>
        <button class="btn btn-primary" onclick="openCertificateModal('${user.name}', '${user.profession}', ${user.score})">
          📜 Elektron Sertifikatni Ko‘rish va Yuklab Olish
        </button>
      `;
    } else if (user.task_submission_url) {
      resultsBox.innerHTML = `
        <div style="padding: 1.5rem; text-align: center;">
          <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">⏳</div>
          <p style="color: #cbd5e1; font-weight: 600;">Topshirig‘ingiz qabul qilindi!</p>
          <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">
            Hakamlar hay'ati 10-20 noyabr kunlari ballarni e'lon qiladi.
          </p>
        </div>
      `;
    } else {
      resultsBox.innerHTML = `
        <div style="padding: 1.5rem; text-align: center; color: var(--text-muted);">
          <div style="font-size: 2.2rem; margin-bottom: 0.5rem;">🎯</div>
          <p>Topshiriq hali topshirilmagan. Natijalarni ko‘rish uchun loyihangiz havolasini yuboring.</p>
        </div>
      `;
    }
  }

  // Render guidelines for profession
  renderProfessionBrief(user.profession);
}

function renderProfessionBrief(prof) {
  const container = document.getElementById('profession-brief-container');
  if (!container) return;

  const data = {
    web_dev: {
      title: "Web sayt yaratish yo‘nalishi talablari",
      desc: "Zamonaviy veb ilova ishlab chiqish. Loyiha to‘liq responsive, toza kodli va yuqori tezlikka ega bo‘lishi lozim.",
      points: [
        "HTML5 semantikasi va zamonaviy CSS (Flexbox/Grid/Tailwind)",
        "JavaScript (ES6+) yoki zamonaviy freymvork (React, Vue, Svelte)",
        "Barcha ekran o‘lchamlariga (Desktop, Mobile) to‘liq moslashuvchanlik",
        "GitHub havolasi va to‘liq tavsiflangan README fayli"
      ]
    },
    web_design: {
      title: "Web dizayner yo‘nalishi talablari",
      desc: "Kreativ veb interfeys va mahsulot dizayni. Figma dasturida to‘liq UI kit, tipografika va interaktiv prototip.",
      points: [
        "Desktop (1440px) va Mobile (390px) to‘liq ekranlari",
        "Komponentlar tizimi (Auto-layout, Variants, Variables)",
        "UX qulayligi va zamonaviy ranglar uyg‘unligi",
        "Ochiq ko‘rish huquqi bilan Figma loyiha havolasi"
      ]
    },
    mobilography: {
      title: "Mobilograf yo‘nalishi talablari",
      desc: "Smartfon yordamida olingan kinematografik video. Dinamik montaj, to‘g‘ri rang korreksiyasi va hikoya (storytelling).",
      points: [
        "Vertikal format (9:16) 1080p yoki 4K 60fps",
        "Davomiyligi: 30 soniyadan 90 soniyagacha",
        "Ovoz effektlari, musiqiy ritm va silliq montaj o‘tishlari",
        "Google Drive yoki YouTube/Telegram havolasi"
      ]
    }
  };

  const info = data[prof] || data.web_dev;
  container.innerHTML = `
    <h3 style="font-size: 1.15rem; font-weight: 700; color: #fff; margin-bottom: 0.5rem;">${info.title}</h3>
    <p style="color: var(--text-secondary); margin-bottom: 1.25rem; font-size: 0.92rem;">${info.desc}</p>
    <ul style="list-style: none; display: flex; flex-direction: column; gap: 0.6rem;">
      ${info.points.map(p => `
        <li style="display: flex; align-items: flex-start; gap: 0.6rem; color: #cbd5e1; font-size: 0.88rem;">
          <span style="color: var(--accent-cyan); font-weight: bold;">✔</span> ${p}
        </li>
      `).join('')}
    </ul>
  `;
}

function initDashboardForms() {
  // Task submission
  const taskForm = document.getElementById('task-submission-form');
  if (taskForm) {
    taskForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const url = document.getElementById('task-submission-url').value.trim();
      const notes = document.getElementById('task-submission-notes').value.trim();

      if (!url) {
        showToast('Loyiha havolasini kiriting!', 'error');
        return;
      }

      const res = DB.submitTask(url, notes);
      if (res.success) {
        showToast(t('alert_task_success'), 'success');
        renderDashboard();
      }
    });
  }

  // Profile update
  const profileForm = document.getElementById('profile-settings-form');
  if (profileForm) {
    profileForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('settings-name').value.trim();
      const email = document.getElementById('settings-email').value.trim();
      const profession = document.getElementById('settings-profession').value;
      const phone = document.getElementById('settings-phone').value.trim();
      const telegram = document.getElementById('settings-telegram').value.trim();
      const password = document.getElementById('settings-password').value;

      const res = DB.updateProfile({ name, email, profession, phone, telegram, password });
      if (res.success) {
        showToast(t('alert_profile_updated'), 'success');
        renderDashboard();
        updateAuthUI();
      } else {
        showToast(res.message, 'error');
      }
    });
  }
}

// ===================================================================
// ADMIN PANEL LOGIC
// ===================================================================

function initAdminView() {
  const searchInput = document.getElementById('admin-search-input');
  const profSelect = document.getElementById('admin-filter-prof');

  if (searchInput) searchInput.addEventListener('input', renderAdminTable);
  if (profSelect) profSelect.addEventListener('change', renderAdminTable);

  const gradeForm = document.getElementById('grade-form');
  if (gradeForm) {
    gradeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!selectedParticipantId) return;

      const score = document.getElementById('grade-score').value;
      const feedback = document.getElementById('grade-feedback').value.trim();

      const res = DB.gradeParticipant(selectedParticipantId, score, feedback);
      if (res.success) {
        showToast('Baholash muvaffaqiyatli saqlandi!', 'success');
        closeModal('grade-modal');
        renderAdminTable();
      }
    });
  }
}

function renderAdminTable() {
  const stats = DB.getStats();
  document.getElementById('stat-total-users').textContent = stats.total;
  document.getElementById('stat-web-dev').textContent = stats.web_dev;
  document.getElementById('stat-web-design').textContent = stats.web_design;
  document.getElementById('stat-mobilography').textContent = stats.mobilography;
  document.getElementById('stat-submissions').textContent = stats.submissions;

  const search = document.getElementById('admin-search-input').value.trim();
  const prof = document.getElementById('admin-filter-prof').value;
  const users = DB.getParticipants(prof, search);

  const tbody = document.getElementById('admin-table-body');
  if (!tbody) return;

  if (users.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--text-muted);">Ishtirokchilar topilmadi.</td></tr>`;
    return;
  }

  const profLabels = {
    web_dev: 'Web sayt yaratish',
    web_design: 'Web dizayner',
    mobilography: 'Mobilograf'
  };

  tbody.innerHTML = users.map(u => `
    <tr>
      <td>
        <div style="font-weight: 700; color: #fff;">${u.name}</div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">${u.email}</div>
      </td>
      <td><span class="prof-pill">${profLabels[u.profession] || u.profession}</span></td>
      <td><span class="status-indicator status-${u.competition_status}">${u.competition_status}</span></td>
      <td>
        ${u.task_submission_url 
          ? `<a href="${u.task_submission_url}" target="_blank" class="table-link">🔗 Havola</a>` 
          : `<span style="color: var(--text-muted); font-size: 0.82rem;">Topshirilmagan</span>`}
      </td>
      <td>
        ${u.score !== null 
          ? `<span class="score-badge">${u.score} ball</span>` 
          : `<span style="color: var(--text-muted); font-size: 0.82rem;">Baholanmagan</span>`}
      </td>
      <td>
        <button class="btn-sm btn-grade" onclick="openGradeModal(${u.id}, '${u.name.replace(/'/g, "\\'")}', ${u.score !== null ? u.score : "null"}, '${(u.jury_feedback || "").replace(/'/g, "\\'")}')">
          ⭐ Baholash
        </button>
      </td>
    </tr>
  `).join('');
}

function openGradeModal(userId, name, currentScore, currentFeedback) {
  selectedParticipantId = userId;
  document.getElementById('grade-participant-name').textContent = name;
  document.getElementById('grade-score').value = currentScore !== null ? currentScore : '';
  document.getElementById('grade-feedback').value = currentFeedback || '';
  openModal('grade-modal');
}

// ===================================================================
// WINNERS SECTION
// ===================================================================

function renderWinners() {
  const container = document.getElementById('winners-container');
  if (!container) return;

  const winners = DB.getWinners();
  const profLabels = {
    web_dev: { uz: 'Web sayt yaratish', ru: 'Веб-разработка', en: 'Web Development' },
    web_design: { uz: 'Web dizayner', ru: 'Веб-дизайнер', en: 'Web Designer' },
    mobilography: { uz: 'Mobilograf', ru: 'Мобилограф', en: 'Mobilographer' }
  };
  const medals = { 1: '🥇', 2: '🥈', 3: '🥉' };
  const rings = { 1: 'ring-gold', 2: 'ring-silver', 3: 'ring-bronze' };

  container.innerHTML = winners.map(w => {
    const profName = (profLabels[w.profession] && profLabels[w.profession][currentLang]) || w.profession;
    const achievement = currentLang === 'ru' ? w.achievement_ru : (currentLang === 'en' ? w.achievement_en : w.achievement);
    const prize = currentLang === 'ru' ? w.prize_ru : (currentLang === 'en' ? w.prize_en : w.prize);

    return `
      <div class="glass-card podium-card podium-${w.rank}st">
        <div class="podium-medal">${medals[w.rank]}</div>
        <div class="winner-avatar-ring ${rings[w.rank]}">
          <img src="${w.avatar}" alt="${w.name}" class="winner-avatar-img">
        </div>
        <div class="winner-prof-badge">${profName}</div>
        <h3 class="winner-name">${w.name}</h3>
        <div class="winner-score">🏆 ${t('score_label')} ${w.score} / 100</div>
        <p class="winner-achievement">${achievement}</p>
        <div class="winner-prize-tag">🎁 ${prize}</div>
      </div>
    `;
  }).join('');
}

// ===================================================================
// MODALS & HELPERS
// ===================================================================

function initModals() {
  document.querySelectorAll('.modal-close-btn, .modal-backdrop').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop') || e.target.closest('.modal-close-btn')) {
        closeAllModals();
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAllModals();
  });

  const toRegisterBtn = document.getElementById('switch-to-register');
  if (toRegisterBtn) {
    toRegisterBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('login-modal');
      openModal('register-modal');
    });
  }

  const toLoginBtn = document.getElementById('switch-to-login');
  if (toLoginBtn) {
    toLoginBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('register-modal');
      openModal('login-modal');
    });
  }

  const forgotBtn = document.getElementById('forgot-password-link');
  if (forgotBtn) {
    forgotBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal('login-modal');
      openModal('reset-modal');
    });
  }

  const resetForm = document.getElementById('reset-form');
  if (resetForm) {
    resetForm.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Parolni tiklash havolasi emailingizga yuborildi!', 'success');
      closeModal('reset-modal');
    });
  }
}

function openModal(modalId, profession = null) {
  closeAllModals();
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    if (modalId === 'register-modal' && profession) {
      const select = document.getElementById('reg-profession');
      if (select) select.value = profession;
    }
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('show'));
  document.body.style.overflow = '';
}

function joinProfession(profKey) {
  openModal('register-modal', profKey);
}

function initFaqAccordion() {
  const items = document.querySelectorAll('.faq-item');
  items.forEach(item => {
    const header = item.querySelector('.faq-header');
    header.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      items.forEach(i => i.classList.remove('active'));
      if (!isActive) item.classList.add('active');
    });
  });
}

function initMobileNav() {
  const hamburger = document.getElementById('hamburger-btn');
  const drawer = document.getElementById('mobile-drawer');
  const closeDrawer = document.getElementById('close-drawer-btn');

  if (hamburger && drawer) hamburger.addEventListener('click', () => drawer.classList.add('open'));
  if (closeDrawer && drawer) closeDrawer.addEventListener('click', () => drawer.classList.remove('open'));

  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', () => {
      if (drawer) drawer.classList.remove('open');
    });
  });
}

function showFieldError(elId, msg) {
  const el = document.getElementById(elId);
  if (el) {
    el.innerText = msg;
    el.classList.add('visible');
  }
}

function clearErrors(form) {
  form.querySelectorAll('.field-error-msg').forEach(el => {
    el.innerText = '';
    el.classList.remove('visible');
  });
}

function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span style="font-size: 1.2rem;">${type === 'success' ? '✅' : '⚠️'}</span>
    <span style="flex: 1;">${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 50);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// Certificate generator modal
function openCertificateModal(name, profession, score) {
  const profNames = {
    web_dev: 'Web sayt yaratish (Web Development)',
    web_design: 'Web dizayner (UI/UX Design)',
    mobilography: 'Mobilograf (Mobilography)'
  };
  const certModal = document.getElementById('certificate-modal');
  if (!certModal) return;

  document.getElementById('cert-name').textContent = name;
  document.getElementById('cert-prof').textContent = profNames[profession] || profession;
  document.getElementById('cert-score').textContent = `${score} / 100 Ball`;
  document.getElementById('cert-date').textContent = new Date().toLocaleDateString();

  openModal('certificate-modal');
}
