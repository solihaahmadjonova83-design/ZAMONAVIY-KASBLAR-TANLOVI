// Client-Side Database & Session Engine for GitHub Pages (HTML/CSS/JS)
const DB = {
  USERS_KEY: 'zk_users_db',
  CURRENT_USER_KEY: 'zk_active_user',
  WINNERS_KEY: 'zk_winners_db',

  init() {
    // Seed default admin and participants if not exists
    if (!localStorage.getItem(this.USERS_KEY)) {
      const defaultUsers = [
        {
          id: 1,
          name: "Bosh Administrator",
          email: "admin@kasblar.uz",
          password: "Admin2026!",
          profession: "web_dev",
          role: "admin",
          phone: "+998 71 200 00 26",
          telegram: "@kasblar_admin",
          competition_status: "verified",
          score: 100,
          task_submission_url: "",
          task_submission_notes: "",
          created_at: new Date().toISOString()
        },
        {
          id: 2,
          name: "Sardor Rahimqulov",
          email: "sardor@example.uz",
          password: "Kasblar2026!",
          profession: "web_dev",
          role: "user",
          phone: "+998 90 111 22 33",
          telegram: "@sardor_dev",
          competition_status: "evaluated",
          score: 94.0,
          jury_feedback: "Ajoyib Next.js platformasi, kod toza va komponentlar to'g'ri ajratilgan.",
          task_submission_url: "https://github.com/sardor/edu-platform",
          task_submission_notes: "To'liq responsive Next.js web platformasi yaratildi.",
          created_at: new Date().toISOString()
        },
        {
          id: 3,
          name: "Laylo Azimova",
          email: "laylo@example.uz",
          password: "Kasblar2026!",
          profession: "web_design",
          role: "user",
          phone: "+998 93 444 55 66",
          telegram: "@laylo_ui",
          competition_status: "evaluated",
          score: 97.5,
          jury_feedback: "Dizayn tizimi juda tartibli, ranglar va tipografika uyg'unligi yuqori darajada.",
          task_submission_url: "https://figma.com/@laylo/kasblar-design-system",
          task_submission_notes: "To'liq UI/UX dizayn tizimi va mobil adaptatsiya tayyorlandi.",
          created_at: new Date().toISOString()
        },
        {
          id: 4,
          name: "Bobur Mirzayev",
          email: "bobur@example.uz",
          password: "Kasblar2026!",
          profession: "mobilography",
          role: "user",
          phone: "+998 97 777 88 99",
          telegram: "@bobur_media",
          competition_status: "evaluated",
          score: 91.0,
          jury_feedback: "Kinematografik montaj va dinamik rang korreksiyasi zo'r chiqdi.",
          task_submission_url: "https://drive.google.com/sample/mobilography-reels",
          task_submission_notes: "4K formatdagi kinematik rolik va musiqiy ritm bilan montaj.",
          created_at: new Date().toISOString()
        },
        {
          id: 5,
          name: "Malika Rustamova",
          email: "malika@example.uz",
          password: "Kasblar2026!",
          profession: "web_design",
          role: "user",
          phone: "+998 90 555 66 77",
          telegram: "@malika_design",
          competition_status: "registered",
          score: null,
          jury_feedback: null,
          task_submission_url: "",
          task_submission_notes: "",
          created_at: new Date().toISOString()
        }
      ];
      localStorage.setItem(this.USERS_KEY, JSON.stringify(defaultUsers));
    }

    // Seed default winners
    if (!localStorage.getItem(this.WINNERS_KEY)) {
      const defaultWinners = [
        {
          rank: 1,
          name: "Jasur Beknazarov",
          profession: "web_dev",
          score: 98.5,
          achievement: "Next-gen AI ta'lim platformasi ekotizimini to'liq ishlab chiqqani uchun",
          achievement_ru: "За разработку экосистемы образовательной ИИ-платформы следующего поколения",
          achievement_en: "For developing a next-gen AI educational platform ecosystem",
          prize: "Apple MacBook Pro M3 + 30 000 000 UZS",
          prize_ru: "Apple MacBook Pro M3 + 30 000 000 UZS",
          prize_en: "Apple MacBook Pro M3 + 30 000 000 UZS",
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
        },
        {
          rank: 2,
          name: "Madina Karimova",
          profession: "web_design",
          score: 96.0,
          achievement: "Fintech ekotizimi uchun qulay, intuitiv dizayn tizimi va interaktiv 3D prototipi",
          achievement_ru: "За интуитивную дизайн-систему финтех-экосистемы и интерактивный 3D-прототип",
          achievement_en: "For an intuitive Fintech design system and interactive 3D prototype",
          prize: "Apple iPhone 16 Pro + 20 000 000 UZS",
          prize_ru: "Apple iPhone 16 Pro + 20 000 000 UZS",
          prize_en: "Apple iPhone 16 Pro + 20 000 000 UZS",
          avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80"
        },
        {
          rank: 3,
          name: "Temur Olimov",
          profession: "mobilography",
          score: 94.2,
          achievement: "Toshkent zamonaviy arxitekturasi bo'yicha kinematografik 4K reels turkumi",
          achievement_ru: "За кинематографическую серию 4K reels о современной архитектуре Ташкента",
          achievement_en: "For a cinematic 4K reels series showcasing Tashkent's modern architecture",
          prize: "Apple iPad Air M2 + 10 000 000 UZS",
          prize_ru: "Apple iPad Air M2 + 10 000 000 UZS",
          prize_en: "Apple iPad Air M2 + 10 000 000 UZS",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
        }
      ];
      localStorage.setItem(this.WINNERS_KEY, JSON.stringify(defaultWinners));
    }
  },

  getAllUsers() {
    return JSON.parse(localStorage.getItem(this.USERS_KEY) || '[]');
  },

  saveAllUsers(users) {
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
  },

  getCurrentUser() {
    const userStr = localStorage.getItem(this.CURRENT_USER_KEY);
    if (!userStr) return null;
    const user = JSON.parse(userStr);
    // Refresh user data from db
    const users = this.getAllUsers();
    const freshUser = users.find(u => u.id === user.id);
    return freshUser || user;
  },

  register(userData) {
    const users = this.getAllUsers();
    const emailLower = userData.email.trim().toLowerCase();

    // Check duplicate
    if (users.some(u => u.email.toLowerCase() === emailLower)) {
      return { success: false, message: 'Bu email orqali allaqachon ro‘yxatdan o‘tilgan!', field: 'email' };
    }

    const newUser = {
      id: Date.now(),
      name: userData.name.trim(),
      email: emailLower,
      password: userData.password,
      profession: userData.profession,
      role: 'user',
      phone: userData.phone || '',
      telegram: userData.telegram || '',
      competition_status: 'registered',
      score: null,
      jury_feedback: null,
      task_submission_url: '',
      task_submission_notes: '',
      created_at: new Date().toISOString()
    };

    users.push(newUser);
    this.saveAllUsers(users);
    localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(newUser));

    return { success: true, user: newUser };
  },

  login(email, password) {
    const users = this.getAllUsers();
    const emailLower = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === emailLower && u.password === password);

    if (!user) {
      return { success: false, message: 'Email yoki parol noto‘g‘ri!' };
    }

    localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
    return { success: true, user };
  },

  logout() {
    localStorage.removeItem(this.CURRENT_USER_KEY);
  },

  updateProfile(updatedData) {
    const currentUser = this.getCurrentUser();
    if (!currentUser) return { success: false, message: 'Tizimga kiring!' };

    const users = this.getAllUsers();
    const idx = users.findIndex(u => u.id === currentUser.id);
    if (idx === -1) return { success: false, message: 'Foydalanuvchi topilmadi!' };

    // Check email uniqueness if changed
    if (updatedData.email && updatedData.email.toLowerCase() !== currentUser.email.toLowerCase()) {
      if (users.some(u => u.id !== currentUser.id && u.email.toLowerCase() === updatedData.email.toLowerCase())) {
        return { success: false, message: 'Ushbu email boshqa foydalanuvchi tomonidan band qilingan!' };
      }
    }

    users[idx] = {
      ...users[idx],
      name: updatedData.name || users[idx].name,
      email: (updatedData.email || users[idx].email).toLowerCase(),
      profession: updatedData.profession || users[idx].profession,
      phone: updatedData.phone !== undefined ? updatedData.phone : users[idx].phone,
      telegram: updatedData.telegram !== undefined ? updatedData.telegram : users[idx].telegram
    };

    if (updatedData.password && updatedData.password.length >= 8) {
      users[idx].password = updatedData.password;
    }

    this.saveAllUsers(users);
    localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(users[idx]));
    return { success: true, user: users[idx] };
  },

  submitTask(url, notes) {
    const currentUser = this.getCurrentUser();
    if (!currentUser) return { success: false, message: 'Tizimga kiring!' };

    const users = this.getAllUsers();
    const idx = users.findIndex(u => u.id === currentUser.id);
    if (idx === -1) return { success: false, message: 'Foydalanuvchi topilmadi!' };

    users[idx].task_submission_url = url;
    users[idx].task_submission_notes = notes;
    users[idx].competition_status = 'task_submitted';

    this.saveAllUsers(users);
    localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(users[idx]));
    return { success: true, user: users[idx] };
  },

  getStats() {
    const users = this.getAllUsers().filter(u => u.role === 'user');
    return {
      total: users.length,
      web_dev: users.filter(u => u.profession === 'web_dev').length,
      web_design: users.filter(u => u.profession === 'web_design').length,
      mobilography: users.filter(u => u.profession === 'mobilography').length,
      submissions: users.filter(u => u.task_submission_url).length
    };
  },

  getParticipants(professionFilter = 'all', searchQuery = '') {
    let users = this.getAllUsers().filter(u => u.role === 'user');

    if (professionFilter && professionFilter !== 'all') {
      users = users.filter(u => u.profession === professionFilter);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      users = users.filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    }

    return users;
  },

  gradeParticipant(participantId, score, feedback) {
    const users = this.getAllUsers();
    const idx = users.findIndex(u => u.id === Number(participantId));
    if (idx === -1) return { success: false, message: 'Ishtirokchi topilmadi!' };

    users[idx].score = Number(score);
    users[idx].jury_feedback = feedback;
    users[idx].competition_status = 'evaluated';

    this.saveAllUsers(users);

    // If current logged-in user was graded, update session too
    const current = this.getCurrentUser();
    if (current && current.id === Number(participantId)) {
      localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(users[idx]));
    }

    return { success: true, user: users[idx] };
  },

  getWinners() {
    return JSON.parse(localStorage.getItem(this.WINNERS_KEY) || '[]');
  }
};

// Auto initialize on load
DB.init();
